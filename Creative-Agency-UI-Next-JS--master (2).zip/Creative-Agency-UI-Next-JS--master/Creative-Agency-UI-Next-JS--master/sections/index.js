import Hero from "./Hero"
import Agency from "./Agency"
import ShowCase from "./ShowCase"
import Team from "./Team"
import Blog from "./Blog"
import Contact from "./Contact"

export { Hero, Agency, Team, ShowCase, Blog, Contact }
